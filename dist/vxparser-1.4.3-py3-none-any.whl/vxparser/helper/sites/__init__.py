from . import dokus4, einschalten, filmpalast, hdfilme, kinokiste, kkiste, megakino, movie2k, movie4k, serienstream, streamcloud, xcine
# hdfilme_1, moflix-stream, topstreamfilm
sites = [dokus4, einschalten, filmpalast, hdfilme, kinokiste, kkiste, megakino, movie2k, movie4k, serienstream, streamcloud, xcine]
