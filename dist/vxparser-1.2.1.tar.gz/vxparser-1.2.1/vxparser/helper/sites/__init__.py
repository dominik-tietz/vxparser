from . import cinemathek, dokus4, filmpalast, hdfilme, kinokiste, kino, kkiste, megakino, movie2k, movie4k, movieking, serienstream, streamcloud, streamen, streampalace, xcine

sites = [cinemathek, dokus4, filmpalast, hdfilme, kinokiste, kino, kkiste, megakino, movie2k, movie4k, movieking, serienstream, streamcloud, streamen, streampalace, xcine] #cineclix, kinofox, kinoger, kinox, netzkino, stumbleupon, moflix]
