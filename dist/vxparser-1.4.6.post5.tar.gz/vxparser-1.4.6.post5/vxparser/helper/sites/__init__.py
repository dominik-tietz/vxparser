from . import einschalten, hdfilme, kinokiste, kkiste, megakino, movie2k, movie4k, serienstream, xcine
# dokus4, hdfilme_1, moflix-stream, topstreamfilm, filmpalast, streamcloud,
sites = [einschalten, hdfilme, kinokiste, kkiste, megakino, movie2k, movie4k, serienstream, xcine]
