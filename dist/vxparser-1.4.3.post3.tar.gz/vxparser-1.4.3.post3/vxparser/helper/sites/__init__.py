from . import dokus4, einschalten, hdfilme, kinokiste, kkiste, megakino, movie2k, serienstream, xcine
# hdfilme_1, moflix-stream, topstreamfilm, filmpalast, movie4k, streamcloud,
sites = [dokus4, einschalten, hdfilme, kinokiste, kkiste, megakino, movie2k, serienstream, xcine]
