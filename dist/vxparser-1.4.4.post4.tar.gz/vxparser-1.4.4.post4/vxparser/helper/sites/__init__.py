from . import dokus4, einschalten, hdfilme, kinokiste, kkiste, megakino, movie2k, movie4k, serienstream
# hdfilme_1, moflix-stream, topstreamfilm, filmpalast, streamcloud, xcine
sites = [dokus4, einschalten, hdfilme, kinokiste, kkiste, megakino, movie2k, movie4k, serienstream]
